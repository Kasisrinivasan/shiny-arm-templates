Configuration WindowsServerDsc
{
  param ($MachineName)

  Node $MachineName
  {
    #Install the IIS Role
    WindowsFeature IIS
    {
      Ensure = "Present"
      Name = "Web-Server"
    }

    #Install ASP.NET 4.5
    WindowsFeature ASP
    {
      Ensure = "Present"
      Name = "Web-Asp-Net45"
    }

   #Install Feature "HTTP Activation"
    WindowsFeature NET-WCF-HTTP-Activation45
    {
          Ensure = "Present"
          Name = "NET-WCF-HTTP-Activation45"
    }

    #Install RoleService 'Message Queuing Activation'
    WindowsFeature NET-WCF-MSMQ-Activation45
    {
        Ensure = "Present"
        Name = "NET-WCF-MSMQ-Activation45"
    }

    #Install Feature "Message Queuing"
		WindowsFeature MSMQ
		{
		    Ensure = "Present"
		    Name = "MSMQ"
		}
      #Install Feature "Message Queuing Services"
        WindowsFeature MSMQ-Services
        {
        Ensure = "Present"
        Name = "MSMQ-Services"
        }
          #Install Feature "Message Queuing Server"
            WindowsFeature MSMQ-Server
            {
                Ensure = "Present"
                Name = "MSMQ-Server"
            }
  }
} 